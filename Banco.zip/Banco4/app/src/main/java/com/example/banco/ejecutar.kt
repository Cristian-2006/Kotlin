package com.example.banco


fun main() {
    val cliente1 = Cliente("Cristian Velandia", "1027401618", 1000.0, "2006", "Cliente")
    val cajero = Cajero(cliente1)

    var ducumentoRecogido = cliente1.documento
    var passwordRecogido = cliente1.pass
    var RolRecogido = cliente1.rol
    var validator : Boolean = true
    while (validator == true) {
        println("A continuacion digite su numero de documento, su contraseña y su rol")
        println("Digite su documento")
        var DocE = readln().toString()
        println("Digite su contraseña")
        var PassE = readln().toString()
        println("Digite su Rol")
        var RolE = readln().toString()
        if (DocE == cliente1.documento && PassE == cliente1.pass) {
            if (RolE == "Admin") {
                println("Que va a realizar?")
                println("Agregar un Cliente")
                var eleccionCliente = readln().toInt()
                when (eleccionCliente){
                    1->{
                        var NombreCliNovo = readln().toString()
                        var DocumentoCliNovo = readln().toString()
                        var SaldoCuentaCliNovo= readln().toDouble()
                        var passwordCliNovo = readln().toString()
                        var rolCliNovo = readln().toString()
                        var ClienteCliNovo = Cliente(NombreCliNovo,DocumentoCliNovo,SaldoCuentaCliNovo,passwordCliNovo,rolCliNovo)
                        val banco = Banco("BBVA","",0.0,"","")
                        banco.agregarCliente(ClienteCliNovo)
                    }

                }



            } else if (RolE == "Cliente") {
                var eleccioClie = readln().toInt()
                println("Que quieres realizar? \n 1.Consinar \n 2.Retirar \n 3. Ver Saldo")
                when (eleccioClie){
                    1->{
                        println("¿Cuanto desea consignar?")
                        var ValorAgg = readln().toFloat()
                        cajero.consignar(ValorAgg)
                        println("La consignacion fue exitosa este es su saldo actualizado ${cliente1.saldoCuenta}"
                        )
                    }
                    2->{
                        println("¿Cuanto desea retirar?")
                        var ValorRetirar = readln().toFloat()
                        cajero.retirar(ValorRetirar)
                        println("El retiro fue exitoso este es su saldo actualizado ${cliente1.saldoCuenta}")

                    }
                    3->{
                        println("Este es su saldo actual ${cliente1.saldoCuenta}")

                    }
                }
            }
            else{
                println("Su acceso fue denegado datos incorrectos")
            }
        }
    }
}




















