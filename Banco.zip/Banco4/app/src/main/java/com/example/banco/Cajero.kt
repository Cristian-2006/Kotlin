package com.example.banco

class Cajero (private val cliente: Cliente) {
    fun consignar(valor: Float) {
        cliente.consignar(valor)
    }
    fun retirar(valor: Float) {
        cliente.retirar(valor)
    }
    fun imprimirSaldo() {
        println("Su saldo actual es: ${cliente.saldoCuenta}")
    }

}